package HockeySim;

/**
 * Agathe Legault
 * April 28, 2022
 * this program implements State interface. action method is what customer with
 * a ticket does
 */
public class Ticket implements State{
    /**
     * action method
     * adds customer to scanner line
     * @param c - customer
     * @param e - hockeyInfo object
     */
    public void action(Customer c, HockeyInfo e, int n){
        System.out.println("\ncustomer from metal detector #" + n + " goes to scanner");
        if(e.getScanLineN(0).size() == 0)
            e.getSemScanner()[0].release();
        e.addScannerCustomer(c);
    }
}
